
public interface Elementos {
		 
	public String getGenero();
	
	public String getID();

	public String getTitulo();
	
	public boolean getTenemos ();
	
	public int getMinutos();
	
	public void setComentario(String c);
	
	public void setMinutos (int m);

}
