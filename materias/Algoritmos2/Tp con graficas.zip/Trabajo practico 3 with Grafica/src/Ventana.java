
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;

public class Ventana extends JFrame{
	JButton boton;
	JTextArea textoArea;
	JPanel panel;
	ArrayList<String> productos = new ArrayList<>();
	
	
	public Ventana() {
		
		this.setSize(500, 500);
		this.setVisible(true);
		this.setTitle("Catalogo De Productos");
		
		panel = new JPanel();
		panel.setSize(500, 500);
		panel.setLayout(null);
		this.getContentPane().add(panel); // agregamos el panel a la ventana
		//panel.setBackground(Color.black);
	
		
		
		colocarLabel();
		colocarCajaTexto();
		colocarBoton();
		listaProductos();
		invocarAction();
	}
	
	
	
	private void invocarAction(){
		ActionListener action = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				productos.add(textoArea.getText());
			}};
			
		boton.addActionListener(action);
	}
	
	
	private void colocarLabel(){
		JLabel label = new JLabel("Agrega tus productos: ");
		label.setBounds(10, 10, 200, 30);
		panel.add(label);
		
		JLabel label1 = new JLabel("Sus productos: ");
		label1.setBounds(10, 250, 200, 30);
		panel.add(label1);
		
	}
	
	private void colocarCajaTexto() {
		textoArea = new JTextArea();
		textoArea.setBounds(10, 50, 170, 75);
		panel.add(textoArea);
	}
	
	
	private void colocarBoton() {
		boton = new JButton("Agregar");
		boton.setBounds(250, 50, 200, 30);
		boton.setBackground(Color.black);
		boton.setForeground(Color.yellow);
		
		panel.add(boton);
	}
	
	
	private void listaProductos(){
		
		JComboBox lista = new JComboBox(productos);
		lista.setBounds(10, 300, 200, 30);
		
	}
	
	
	
}
